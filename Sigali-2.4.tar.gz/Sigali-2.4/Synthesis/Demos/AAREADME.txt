

See the documentation

  html:  AAREADME/html/index.html
or
  pdf:   AAREADME/latex/refman.pdf

