
#ifndef __pKio_h__
#define __pKio_h__


// Windows
#include <iostream.h>
#include <fstream.h>

// Unix/Linux/MacOs (A tester)
// #include <sstream>
//#include <iostream>
//#include <fstream>

#endif
