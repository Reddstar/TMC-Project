EXTERN boolean RAUTO(void);
EXTERN boolean RSTOP(void);
EXTERN boolean RTICK(void);
EXTERN void GET_PACE_RHYTHM(int **descr,int * pi_0);

