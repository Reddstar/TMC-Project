typedef int boolean;
#define TRUE 1
#define FALSE 0

EXTERN boolean RUPDOWN(int *w_pt);
EXTERN int RCHANGE(int *widgst_pt);

