#ifdef _HAVE_64_BITS
typedef long integer;
typedef unsigned long u_integer;
#else
typedef int integer;
typedef unsigned int u_integer;
#endif
