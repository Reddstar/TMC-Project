/* ==================== languageInclude: pointer
 */
#define NIL 0
typedef char *pointer;
#define ISDT_NIL ((void *) 0)

